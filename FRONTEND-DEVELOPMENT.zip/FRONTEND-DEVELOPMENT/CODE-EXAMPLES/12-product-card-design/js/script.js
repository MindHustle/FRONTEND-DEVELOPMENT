// JS for product card interactions (Example: Add to Cart Button Click)

// Select all "Add to Cart" buttons
const buttons = document.querySelectorAll('.add-cart');

// Loop through each button
buttons.forEach(button => {
  button.addEventListener('click', () => {
    // When button clicked, show simple alert (for demo)
    alert('Product added to cart!');
    // You can later replace this with real cart logic
  });
});
