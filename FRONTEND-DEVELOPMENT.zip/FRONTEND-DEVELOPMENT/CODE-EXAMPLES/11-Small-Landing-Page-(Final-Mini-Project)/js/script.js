/* HAMBURGER MENU TOGGLE */
// Select hamburger icon & menu
const hamburger = document.querySelector('.hamburger');
const menu = document.querySelector('.menu');

// Toggle menu visibility when clicking hamburger
hamburger.addEventListener('click', () => {
    menu.classList.toggle('active'); // Add/remove active class
});
